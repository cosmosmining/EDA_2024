#include <iostream>
#include <vector>
#include <queue>
#include <set>
#include <algorithm>
#include <cmath>
#include <climits>
#include <fstream>
#include <numeric>
#include <bits/stdc++.h>
using namespace std;


struct Point
{
    int x, y;
    Point(int x, int y) : x(x), y(y) {}

    bool operator!=(const Point& o) const
    {
        return x != o.x || y != o.y;
    }

    bool operator==(const Point& o) const
    {
        return x == o.x && y == o.y;
    }

    // Define the '<' operator for ordering points
    bool operator<(const Point& o) const
    {
        if (x == o.x) return y < o.y; // If x-coordinates are equal, compare y-coordinates
        return x < o.x; // Otherwise, compare x-coordinates
    }
};


struct Node
{
    Point pt;
    int fCost, gCost;
    Node(Point pt, int f, int g) : pt(pt), fCost(f), gCost(g) {}
};

struct Compare
{
    bool operator()(const Node& a, const Node& b)
    {
        return a.fCost > b.fCost;
    }
};
void markPathOnGrid(vector<vector<int>>& grid, const vector<Point>& path, int pathLabel) {
    for (const Point& point : path) {
        grid[point.x][point.y] = pathLabel;  // Mark the grid cell with the path label
    }
}
void clearPathFromGrid(vector<vector<int>>& grid, const vector<Point>& path) {
    for (const Point& point : path) {
        grid[point.x][point.y] = 0;  // Set the grid cell back to zero to indicate it's free
    }
}
bool isValid(int x, int y, vector<vector<int>>& grid)
{
    return (x >= 0 && x < grid.size() && y >= 0 && y < grid[0].size() && grid[x][y] == 0);
}

int manhattanDistance(Point p1, Point p2)
{
    return abs(p1.x - p2.x) + abs(p1.y - p2.y);
}

vector<Point> findPathAStar(vector<vector<int>>& grid, Point src, Point dest, int pathLabel)
{
    if (src == dest) return {src};

    int rows = grid.size(), cols = grid[0].size();
    vector<vector<int>> cost(rows, vector<int>(cols, INT_MAX));
    priority_queue<Node, vector<Node>, Compare> pq;

    pq.push(Node(src, manhattanDistance(src, dest), 0));
    cost[src.x][src.y] = 0;

    vector<Point> directions = {{0, 1}, {0, -1}, {1, 0}, {-1, 0}};
    vector<vector<Point>> prev(rows, vector<Point>(cols, {-1, -1}));

    while (!pq.empty())
    {
        Node current = pq.top();
        pq.pop();
        Point pt = current.pt;

        if (pt == dest)
        {
            vector<Point> path;
            while (pt.x != -1 && pt.y != -1)
            {
                path.push_back(pt);
                grid[pt.x][pt.y] = pathLabel;
                pt = prev[pt.x][pt.y];
            }
            reverse(path.begin(), path.end());
            return path;
        }

        for (Point dir : directions)
        {
            Point neighbor(pt.x + dir.x, pt.y + dir.y);
            if (isValid(neighbor.x, neighbor.y, grid) && cost[neighbor.x][neighbor.y] > current.gCost + 1)
            {
                prev[neighbor.x][neighbor.y] = pt;
                cost[neighbor.x][neighbor.y] = current.gCost + 1;
                pq.push(Node(neighbor, cost[neighbor.x][neighbor.y] + manhattanDistance(neighbor, dest), cost[neighbor.x][neighbor.y]));
            }
        }
    }

    return {};
}

vector<Point> findPathBFS(vector<vector<int>>& grid, Point src, Point dest) {
    if (src == dest) return {src}; // Path is trivially the source if source equals destination

    int rows = grid.size(), cols = grid[0].size();
    vector<vector<bool>> visited(rows, vector<bool>(cols, false)); // Track visited nodes
    queue<pair<Point, vector<Point>>> q; // Queue to manage the BFS, stores current point and path to it

    q.push({src, {src}}); // Initialize with the source point and path containing just the source
    visited[src.x][src.y] = true; // Mark source as visited

    // Directions for moving in the grid (right, left, down, up)
    vector<Point> directions = {{0, 1}, {0, -1}, {1, 0}, {-1, 0}};

    while (!q.empty()) {
        auto current = q.front();
        q.pop();

        Point pt = current.first;
        vector<Point> path = current.second;

        // Check if the current point is the destination
        if (pt == dest) {
            return path; // Return the path to the destination
        }

        // Explore each possible direction
        for (const Point& dir : directions) {
            Point neighbor(pt.x + dir.x, pt.y + dir.y);
            // Check bounds and whether the cell is walkable and not visited
            if (neighbor.x >= 0 && neighbor.x < rows && neighbor.y >= 0 && neighbor.y < cols &&
                grid[neighbor.x][neighbor.y] == 0 && !visited[neighbor.x][neighbor.y]) {
                visited[neighbor.x][neighbor.y] = true; // Mark as visited
                vector<Point> new_path = path; // Create a new path including this neighbor
                new_path.push_back(neighbor);
                q.push({neighbor, new_path}); // Push the new state to the queue
            }
        }
    }

    return {}; // Return empty path if no path found
}


/*
vector<Point> findPathBFS(vector<vector<int>>& grid, Point src, Point dest) {
    if (src == dest) return {src}; // Path is trivially the source if source equals destination

    int rows = grid.size(), cols = grid[0].size();
    vector<vector<bool>> visited(rows, vector<bool>(cols, false)); // Track visited nodes
    queue<pair<Point, vector<Point>>> q; // Queue to manage the BFS, stores current point and path to it

    q.push({src, {src}}); // Initialize with the source point and path containing just the source
    visited[src.x][src.y] = true; // Mark source as visited

    // Determine directional preference based on the relative positions of src and dest
    vector<Point> directions;
    if (src.x <= dest.x && src.y <= dest.y) {
        // Moving from top-left to bottom-right, prefer down and right
        directions = {{1, 0}, {0, 1}, {0, -1}, {-1, 0}};
    } else if (src.x <= dest.x && src.y >= dest.y) {
        // Moving from top-right to bottom-left, prefer down and left
        directions = {{1, 0}, {0, -1}, {0, 1}, {-1, 0}};
    } else {
        // General case: include all directions
        directions = {{0, 1}, {0, -1}, {1, 0}, {-1, 0}};
    }

    while (!q.empty()) {
        auto current = q.front();
        q.pop();

        Point pt = current.first;
        vector<Point> path = current.second;

        // Check if the current point is the destination
        if (pt == dest) {
            return path; // Return the path to the destination
        }

        // Explore each possible direction
        for (const Point& dir : directions) {
            Point neighbor(pt.x + dir.x, pt.y + dir.y);
            // Check bounds and whether the cell is walkable and not visited
            if (neighbor.x >= 0 && neighbor.x < rows && neighbor.y >= 0 && neighbor.y < cols &&
                grid[neighbor.x][neighbor.y] == 0 && !visited[neighbor.x][neighbor.y]) {
                visited[neighbor.x][neighbor.y] = true; // Mark as visited
                vector<Point> new_path = path; // Create a new path including this neighbor
                new_path.push_back(neighbor);
                q.push({neighbor, new_path}); // Push the new state to the queue
            }
        }
    }

    return {}; // Return empty path if no path found
}

void checkAndPrintOverlaps(const vector<vector<Point>>& paths, const vector<string>& netNames) {
    bool overlapDetected = false;
    for (int i = 0; i < paths.size(); i++) {
        for (int j = i + 1; j < paths.size(); j++) {
            set<Point> pathSet(paths[i].begin(), paths[i].end());
            vector<Point> overlaps;
            for (const Point& point : paths[j]) {
                if (pathSet.find(point) != pathSet.end()) {
                    overlaps.push_back(point);
                }
            }
            if (!overlaps.empty()) {
                overlapDetected = true;
                cout << "Overlap detected between " << netNames[i] << " and " << netNames[j] << " at points: ";
                for (const Point& p : overlaps) {
                    cout << "(" << p.x << "," << p.y << ") ";
                }
                cout << endl;
            }
        }
    }
    if (!overlapDetected) {
        cout << "No overlaps detected among the paths." << endl;
    }
}
*/
set<int> checkAndPrintOverlaps(vector<vector<Point>>& paths, vector<string>& netNames, vector<vector<int>>& grid) {
    set<int> netsToReroute;
    for (int i = 0; i < paths.size(); i++) {
        for (int j = i + 1; j < paths.size(); j++) {
            set<Point> pathSet(paths[i].begin(), paths[i].end());
            for (const Point& point : paths[j]) {
                if (pathSet.find(point) != pathSet.end()) {
                    netsToReroute.insert(i);
                    netsToReroute.insert(j);
                }
            }
        }
    }

    for (int net : netsToReroute) {
        clearPathFromGrid(grid, paths[net]);
        paths[net].clear();
    }

    // Now, netsToReroute contains indices of nets whose paths need rerouting
    return netsToReroute;
}
int main(int argc, char *argv[])
{
//   argv[1] = "test2.txt";
  //  argv[2] = "out.out";

    ifstream fin(argv[1]);
    ofstream fout(argv[2]);
    int row, col;
    string a;
    fin>>a;
   // cout<<a;
    fin>>row;
    string b;
    fin>>b;
    fin>>col;
    vector<vector<int>> grid(row, vector<int>(col, 0));
    string c;
    fin>>c;
    int blocks;
    fin>>blocks;
    for (int i = 0; i < blocks; i++)
    {
        int x1, y1, x2, y2;
        fin >> x1 >> x2 >> y1 >> y2;

        for (int x = x1; x <= x2; x++)
        {
            for (int y = y1; y <= y2; y++)
            {
                int new_x = row - y - 1;
                int new_y = x;
                grid[new_x][new_y] = 1;
            }
        }
    }
    int pathing = 2;
    string d;
    fin>>d;
    int nets;
    fin>>nets;
    vector<pair<Point, Point>> terminals;
    vector<string> netNames;
    vector<int> priorities(nets);
    for (int i = 0; i < nets; i++)
    {
        string netName;
        int sx, sy, tx, ty;
        fin >> netName >> sx >> sy >> tx >> ty;
        int new_sx = row - sy - 1, new_sy = sx, new_tx = row - ty - 1, new_ty = tx;
        terminals.push_back({Point(new_sx, new_sy), Point(new_tx, new_ty)});
        netNames.push_back(netName);
        grid[new_sx][new_sy] = 1;
        grid[new_tx][new_ty] = 1;
        priorities[i] = manhattanDistance(terminals[i].first, terminals[i].second); // Closer terminals are prioritized.
    }

    vector<int> indices(nets);
    iota(indices.begin(), indices.end(), 0);
    sort(indices.begin(), indices.end(), [&](int i, int j)
    {
        return priorities[i] < priorities[j];
    });



   // cout << "Net routing priorities (sorted by Manhattan distance):" << endl;
    for (int i : indices)
    {
    //    cout << "Net Name: " << netNames[i] << ", Manhattan Distance: " << priorities[i] << endl;
    }

    vector<vector<Point>> paths(nets);
    vector<vector<Point>> savedPaths(nets);  // Store successfully routed paths for restoration.
    int pathLabel = 3;
    for (int i : indices)
    {
        for (int j = 0; j < nets; j++)
        {
            if (i != j)
            {
                grid[terminals[j].first.x][terminals[j].first.y] = 1;
                grid[terminals[j].second.x][terminals[j].second.y] = 1;
            }
        }

        grid[terminals[i].first.x][terminals[i].first.y] = 0;
        grid[terminals[i].second.x][terminals[i].second.y] = 0;
     //   vector<Point> path = findPathAStar(grid, terminals[i].first, terminals[i].second, pathLabel);
        vector<Point> path = findPathBFS(grid, terminals[i].first, terminals[i].second);
        if (path.empty() && i > 0)
        {
      //      cout << netNames[i] << endl;
        vector<vector<Point>> tempPaths = savedPaths;  // Save current paths for restoration.

        // Clear the grid except the current net's terminals and re-mark other nets' terminals as blocked
        for (int j = 0; j < nets; j++)
        {
            for (Point p : tempPaths[j])
            {
                grid[p.x][p.y] = 0;  // Temporarily remove the path from the grid.
            }
            // Ensure terminals remain blocked
            if (i != j)
            {
                grid[terminals[j].first.x][terminals[j].first.y] = 1;
                grid[terminals[j].second.x][terminals[j].second.y] = 1;
            }
        }

        // Retry finding a path for the current net
        path = findPathBFS(grid, terminals[i].first, terminals[i].second);
        if (!path.empty())
        {
            paths[i] = path;
            savedPaths[i] = path;
        }
        else
        {
            // Restore previously saved paths if rerouting failed
            for (int j = 0; j < nets; j++)
            {
                for (Point p : tempPaths[j])
                {
                    grid[p.x][p.y] = 2;  // Restore the path on the grid.
                    // Ensure terminals remain blocked
                    if (i != j)
                    {
                        grid[terminals[j].first.x][terminals[j].first.y] = 1;
                        grid[terminals[j].second.x][terminals[j].second.y] = 1;
                    }
                }
            }
        //    cout << "Rerouting failed, restored previous paths." << endl;
        }

        }
        else if (!path.empty())
        {
            paths[i] = path;
            savedPaths[i] = path;  // Save the successful path.
        }
        pathLabel++;
        //int pathing = 2;
        for (int j = 0; j < nets; j++)
        {
            if (!paths[j].empty())    // Only set back paths that are successful.
            {
                for (Point p : paths[j])
                {
                    grid[p.x][p.y] = pathing ;  // Mark the path on the grid.
                }
            }
            pathing++;
        }
        
         for (int i = 0; i < row; ++i)
    {
        for (int j = 0; j < col; ++j)
        {
            //cout << grid[i][j] << " ";
        }
       // cout << endl;
    }
    
    
    //cout<<endl<<endl;
    }

    for (int i = 0; i < row; ++i)
    {
        for (int j = 0; j < col; ++j)
        {
           // cout << grid[i][j] << " ";
        }
       // cout << endl;
    }
   // cout<<endl<<endl;

    vector<bool> successfullyRouted(nets, false);

    



//checkAndPrintOverlaps(paths, netNames);
//set<int> netsToReroute = checkAndPrintOverlaps(paths, netNames, grid);



// Now you can continue with your existing code where you handle other parts of the logic
set<int> netsToReroute = checkAndPrintOverlaps(paths, netNames, grid);

// Sort nets by descending Manhattan distance for rerouting
vector<int> rerouteOrder(netsToReroute.begin(), netsToReroute.end());
sort(rerouteOrder.begin(), rerouteOrder.end(), [&](int i, int j) {
    return priorities[i] > priorities[j];
});

// Reroute the affected nets
for (int index : rerouteOrder) {
    vector<Point> path = findPathBFS(grid, terminals[index].first, terminals[index].second);
    if (!path.empty()) {
        paths[index] = path;
        markPathOnGrid(grid, path, index + 2);  // Assumes path labels start from 2
        savedPaths[index] = path;
    }
}

//cout
    for (int i = 0; i < nets; i++)
    {
        if (!paths[i].empty())
        {

            vector<Point> path = paths[i];
            vector<Point> corners;
            corners.push_back(path[0]);  // Start point
            for (size_t j = 1; j < path.size() - 1; ++j)
            {
                if (path[j - 1].x != path[j + 1].x && path[j - 1].y != path[j + 1].y)
                {
                    corners.push_back(path[j]);  // Corner point
                }
            }
            corners.push_back(path.back());  // End point

            fout << netNames[i];
            fout << " " << path.size()-2 << endl;
            fout << "begin" << endl;
            for (size_t k = 0; k < corners.size()-1; ++k)
            {
                fout << corners[k].y << " " << row - corners[k].x - 1;
                fout << " " << corners[k+1].y << " " << row - corners[k+1].x - 1 << endl;
            }
            fout << "end" << endl;
        }
    }



    return 0;
}

