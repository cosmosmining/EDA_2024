
# Maze Pathfinding

This project involves pathfinding in a maze using the A* and BFS algorithms. The code reads a grid representation of the maze from an input file, identifies paths between specified terminal points, and detects overlaps between paths.

## Files

- `maze102.cpp`: The main source code file containing the implementation of the pathfinding algorithms.
- `lab3`: An input file for testing the pathfinding algorithms.
- `Makefile`: Makefile to compile the project.

## Compilation

To compile the project, use the provided Makefile. Run the following command in the project directory:

```sh
make
```
This will compile the `maze102.cpp` file and generate an executable named `maze`.

## Usage

To run the executable, use the following command:

```sh
./maze <input_file> <output_file>
```

- `<input_file>`: Path to the input file containing the maze grid and terminal points.
- `<output_file>`: Path to the output file where the results will be written.

Example:

```sh
./maze lab3 output.txt
```

## Input File Format

The input file should be formatted as follows:

```
Type: Grid
<row_count>
Columns: <column_count>
Blocked:
<number_of_blocked_areas>
<blocked_area_1_start_x> <blocked_area_1_start_y> <blocked_area_1_end_x> <blocked_area_1_end_y>
...
Nets:
<number_of_nets>
<net_name_1> <start_x_1> <start_y_1> <end_x_1> <end_y_1>
...
```

### Example:

```
Type: Grid
10
Columns: 10
Blocked:
2
1 1 3 3
5 5 7 7
Nets:
2
net1 0 0 9 9
net2 9 0 0 9
```

## Output File Format

The output file will list the routes for each net, including the number of segments in the path and the coordinates of the path corners.

### Example:

```
net1 4
begin
0 0 0 9
0 9 9 9
9 9 9 0
9 0 0 0
end
net2 4
begin
9 0 9 9
9 9 0 9
0 9 0 0
0 0 9 0
end
```

## Pathfinding Algorithms

### A*

The A* algorithm is used for finding the shortest path in the maze. It uses a priority queue to explore paths based on the sum of the cost to reach a point and an estimate of the cost to the goal (Manhattan distance).

### BFS

The BFS algorithm is used as an alternative to find paths in the maze. It uses a queue to explore all possible paths level by level until it finds the shortest path to the goal.

## Error Handling

The code includes error handling for various scenarios, such as when no path is found between the specified terminals. It also attempts to reroute paths in case of overlaps between different nets.

## License

This project is licensed under the MIT License - see the [LICENSE](LICENSE) file for details.
