#include <iostream>
#include <fstream>
#include <vector>
#include <list>
#include <sstream>
#include <limits>
#include <ios>
#include <bits/stdc++.h>
using namespace std;

void labelPropagation(vector<int>& partition, const vector<vector<int>>& adjList, int num_partitions) {
    random_device rd;
    mt19937 g(rd());
    int n = adjList.size() - 1;
    vector<int> counts(num_partitions, 0);
    int minSize = int(ceil(n * 0.45));
    int maxSize = int(floor(n * 0.55));

    for (int i = 1; i <= n; ++i) {
        int chosenPartition;
        do {
            chosenPartition = g() % num_partitions;
        } while (counts[chosenPartition] >= maxSize);
        partition[i] = chosenPartition;
        counts[chosenPartition]++;
    }

    bool changed;
    int maxIterations = 100;  
    int iterations = 0;
    do {
        changed = false;
        vector<int> newPartition(partition);

        for (int i = 1; i <= n; ++i) {
            unordered_map<int, int> label_count;
            for (int neighbor : adjList[i]) {
                label_count[partition[neighbor]]++;
            }

            int max_label = partition[i], max_count = label_count[max_label];
            for (const auto& label : label_count) {
                if (label.second > max_count || (label.second == max_count && label.first < max_label)) {
                    max_label = label.first;
                    max_count = label.second;
                }
            }

            if (max_label != partition[i] && counts[partition[i]] > minSize && counts[max_label] < maxSize) {
                newPartition[i] = max_label;
                counts[partition[i]]--;
                counts[max_label]++;
                changed = true;
            }
        }
        partition = newPartition;
    } while (changed && ++iterations < maxIterations);
}

void greedyGrowthInit(const vector<vector<int>>& adjList, vector<int>& partition, int n) {
    vector<bool> selected(n + 1, false);
    int minSize = int(ceil(n * 0.45));
    int maxSize = int(floor(n * 0.55));

    // Start by selecting the most connected node
    int startNode = 1;
    for (int i = 2; i <= n; ++i) {
        if (adjList[i].size() > adjList[startNode].size()) {
            startNode = i;
        }
    }

    // Initialize the first partition
    partition[startNode] = 1;
    selected[startNode] = true;
    int count = 1;

    // Pre-calculate neighbor connections only for non-selected nodes
    vector<int> connectionWeights(n + 1, 0);
    for (int neighbor : adjList[startNode]) {
        if (!selected[neighbor]) {
            connectionWeights[neighbor]++;
        }
    }

    // Grow the partition efficiently
    while (count < maxSize) {
        int maxConnection = -1;
        int candidate = -1;

        // Find the node with the highest connection weight to the current partition
        for (int i = 1; i <= n; ++i) {
            if (!selected[i] && connectionWeights[i] > maxConnection) {
                maxConnection = connectionWeights[i];
                candidate = i;
            }
        }

        if (candidate == -1 || (count >= minSize && count >= maxSize)) break; // Stop if no candidates or balance exceeded

        partition[candidate] = 1;
        selected[candidate] = true;
        count++;

        // Update connection weights based on the newly added node
        for (int neighbor : adjList[candidate]) {
            if (!selected[neighbor]) {
                connectionWeights[neighbor]++;
            }
        }
    }

    // Assign remaining nodes to the second partition
    for (int i = 1; i <= n; ++i) {
        if (!selected[i]) {
            partition[i] = 0;
        }
    }
}


void updateValues(vector<int>& D, vector<int>& I, vector<int>& E, const vector<vector<int>>& adj, int p, int q, vector<int>& partition)
{
    D[p] = D[q] = I[p] = E[p] = I[q] = E[q] = 0;

    for (int i = 1; i < adj.size(); ++i)
    {
        if (i != p && i != q)
        {
            if (partition[i] == partition[p])
            {
                I[p] += adj[i][p];
                E[p] += adj[i][q];
                I[q] += adj[i][q];
                E[q] += adj[i][p];
            }
            else
            {
                E[p] += adj[i][p];
                I[p] += adj[i][q];
                E[q] += adj[i][q];
                I[q] += adj[i][p];
            }
        }
    }

    for (int i = 1; i < adj.size(); ++i)
    {
        if (i != p && i != q)
        {
            if (partition[i] == partition[p] || partition[i] == partition[q])
            {
                int adjust_p = (partition[i] == partition[p]) ? p : q;
                int adjust_q = (partition[i] == partition[p]) ? q : p;

                E[i] -= adj[i][adjust_p];
                E[i] += adj[i][adjust_q];
                I[i] += adj[i][adjust_p];
                I[i] -= adj[i][adjust_q];
                D[i] = E[i] - I[i];
            }
        }
    }

    D[p] = E[p] - I[p];
    D[q] = E[q] - I[q];
}

int calculateCutCost(const vector<vector<int>>& adjList, const vector<int>& partition)
{
    int cost = 0;
    for (int i = 1; i < adjList.size(); ++i)
    {
        for (int j : adjList[i])
        {
            if (i < j && partition[i] != partition[j])
            {
                cost++;
            }
        }
    }
    return cost;
}




void updateDValues(vector<int>& D, vector<int>& I, vector<int>& E, const vector<vector<int>>& adjList, int node, vector<int>& partition, int& partition0Count)
{
    int oldPartition = partition[node];
    partition[node] = 1 - oldPartition;
    if (partition[node] == 0)
    {
        partition0Count++;
    }
    else
    {
        partition0Count--;
    }

    const vector<int>& neighbors = adjList[node];
    int numNeighbors = neighbors.size();

    // Unroll loop by factor of 4
    int i = 0;
    for (; i <= numNeighbors - 4; i += 4)
    {
        for (int j = 0; j < 4; ++j)
        {
            int neighbor = neighbors[i + j];
            int delta = (partition[neighbor] == oldPartition) ? -1 : 1;
            I[neighbor] += delta;
            E[neighbor] -= delta;
            I[node] += delta;
            E[node] -= delta;
            D[neighbor] = E[neighbor] - I[neighbor];
        }
    }

    // Handle remaining neighbors
    for (; i < numNeighbors; ++i)
    {
        int neighbor = neighbors[i];
        int delta = (partition[neighbor] == oldPartition) ? -1 : 1;
        I[neighbor] += delta;
        E[neighbor] -= delta;
        I[node] += delta;
        E[node] -= delta;
        D[neighbor] = E[neighbor] - I[neighbor];
    }

    D[node] = E[node] - I[node];
}


int main(int argc, char* argv[])
{
 if (argc < 2) {
        cerr << "Usage: " << argv[0] << " <input_file>.hgr" << endl;
        return 1;
    }

    string inputFilename = argv[1];
   // string outputFilename = inputFilename + ".part.2";
    ios::sync_with_stdio(false);  // Disable synchronization between C and C++ standard streams
    ifstream fin(inputFilename);
    ofstream fout("output.txt");

    int nets, n;
    fin >> nets >> n;

    if (n < 6)
    {
        vector<vector<int>> adj(n + 1, vector<int>(n + 1, 0));

fin.ignore();  // Skip to the next line after reading nets and n
for (int net = 0; net < nets; ++net) {
    string line;
    getline(fin, line);
    stringstream ss(line);
    int current, next;

    // Read the first node
    if (!(ss >> current)) continue;  // Skip empty lines

    // Read and connect subsequent nodes
    while (ss >> next) {
        adj[current][next] = adj[next][current] = 1;
        current = next;  // Move to the next node for the upcoming pair
    }
}

        vector<int> partition(n + 1, 0);
        int half = n / 2;
        for (int i = 1; i <= half; ++i) partition[i] = 0;
        for (int i = half + 1; i <= n; ++i) partition[i] = 1;

        vector<int> I(n + 1, 0), E(n + 1, 0), D(n + 1, 0), locked(n + 1, 0);
        int originalCost = calculateCutCost(adj, partition);
        int count = 0, maxG, maxI, maxJ;

        do
        {
            count++;
            fill(I.begin(), I.end(), 0);
            fill(E.begin(), E.end(), 0);
            fill(D.begin(), D.end(), 0);
            maxG = numeric_limits<int>::min();

            for (int i = 1; i <= n; i++)
            {
                for (int j = 1; j <= n; j++)
                {
                    if (i != j)
                    {
                        if (partition[i] == partition[j]) I[i] += adj[i][j];
                        else E[i] += adj[i][j];
                    }
                }
                D[i] = E[i] - I[i];
            }

            for (int i = 1; i <= n; i++)
            {
                for (int j = i + 1; j <= n; j++)
                {
                    if (!locked[i] && !locked[j] && partition[i] != partition[j])
                    {
                        int g = D[i] + D[j] - 2 * adj[i][j];
                        if (g > maxG)
                        {
                            maxG = g;
                            maxI = i;
                            maxJ = j;
                        }
                    }
                }
            }

            if (maxG <= 0) break;
            swap(partition[maxI], partition[maxJ]);
            locked[maxI] = locked[maxJ] = true;
            updateValues(D, I, E, adj, maxI, maxJ, partition);

        }
        while (true);


      //  int modifiedCost = calculateCutCost(adj, partition);

        //cout << "Modified cut cost: " << modifiedCost << '\n';
        for(int i = 1; i< partition.size(); i++)
        {
            fout<<partition[i]<<endl;
        }
        fin.close();
        fout.close();
        return 0;
    }
/*
    vector<vector<int>> adjList(n + 1);

fin.ignore();  // Skip to the next line after reading nets and n
for (int net = 0; net < nets; ++net) {
    string line;
    getline(fin, line);
    istringstream ss(line);
    vector<int> nodes;
    int node;

    // Read all nodes into a vector from the line
    while (ss >> node) {
        nodes.push_back(node);
    }

    // Connect each pair of consecutive nodes
    for (size_t i = 0; i < nodes.size() - 1; ++i) {
        int first = nodes[i];
        int second = nodes[i + 1];
        adjList[first].push_back(second);
        adjList[second].push_back(first);
        cout<< first<<second<<endl;
    }
}
*/

    vector<vector<int>> adjList(n + 1);

    fin.ignore();  // Skip to the next line after reading nets and n
    for (int net = 0; net < nets; ++net)
    {
        string line;
        getline(fin, line);
        istringstream ss(line);
        int first, second;
        ss >> first;
        while (ss >> second)
        {
            adjList[first].push_back(second);
            adjList[second].push_back(first);
        }
    }


    vector<int> partition(n + 1, 0);
    if(n < 10000)
    greedyGrowthInit(adjList, partition, n);
    else
    {

        // greedyGrowthInit(adjList, partition, n);
         labelPropagation(partition, adjList, 2);
    }

    // Balancing partitions according to the specified balance factor
    /*int partitionSize = max(int(ceil(n * 0.45)), n / 2); // Ensure the smaller partition is at least 45% of n
    if (partitionSize > n * 0.5) partitionSize = int(n * 0.5); // Cap at 50% of n
    for (int i = 1; i <= partitionSize; ++i)
    {
        partition[i] = 1;
    }
*/

    int partition0Count = 0;
    for(int i = 0; i < partition.size(); i++)
    {
        if(partition[i]== 0)
            partition0Count++;
    }
    vector<int> temp = partition;

//    int    modifiedCost = calculateCutCost(adjList, partition);
  //  cout << "Modified cut cost: " << modifiedCost << endl;
    vector<int> I(n + 1, 0), E(n + 1, 0), D(n + 1, 0);
    for (int i = 1; i <= n; ++i)
    {
        for (int j : adjList[i])
        {
            if (partition[i] == partition[j])
            {
                I[i]++;
            }
            else
            {
                E[i]++;
            }
        }
        D[i] = E[i] - I[i];
    }

    int iteration = 0;
    bool improved = true;
    vector<bool> locked(n + 1, false);
    vector<int> partial (n+1, 0);
    vector<int> m (n+1, 0);
    int k = 0;
    while (improved&&iteration<n)
    {
        improved = false;
        int maxGain = numeric_limits<int>::min();
        int bestNode = 0;
        for (int i = 1; i <= n; ++i)
        {
            if (!locked[i] && D[i] > maxGain)
            {
                // Check if swapping would violate balance factor constraints
                int potentialPartition0Count = partition[i] == 0 ? partition0Count - 1 : partition0Count + 1;
                if (potentialPartition0Count >= ceil(n * 0.45) && potentialPartition0Count <= floor(n * 0.55))
                {
                    maxGain = D[i];
                    bestNode = i;
                }
            }
        }
        if (bestNode > 0  )
        {
            updateDValues(D, I, E, adjList, bestNode, partition, partition0Count);
            partial [k] = maxGain;
            m[k] = bestNode;
            // locked[bestNode] = true;
            improved = true;
            k++;
        }
        iteration++;
    }
    int max_sum = INT_MIN; // Initialize to the smallest possible integer
    int max_index = -1;
    int current_sum = 0;

    // Iterate over the vector to calculate the maximum partial sum
    for (int i = 0; i < partial.size(); ++i)
    {
        current_sum += partial[i]; // Update the current sum with each element

        // Check if the current sum is greater than the max sum found so far
        if (current_sum > max_sum)
        {
            max_sum = current_sum; // Update max sum
            max_index = i; // Record the index of the max sum
        }
    }

    // Output the results
    //std::cout << "Maximum partial sum is: " << max_sum

      //        << " at index " << max_index << std::endl;
    /*int half = n/2;
    for (int i = 1; i <= half; ++i) partition[i] = 0;

    for (int i = half + 1; i <= n; ++i) partition[i] = 1;
        */
    partition = temp;
    for(int i = 1; i <=max_index+1; i++)
    {
        if(partition[m[i]] == 0)
            partition[m[i]] = 1;
        else
            partition[m[i]] = 0;
    }


    for (int i = 1; i <= n; ++i)
    {
        fout << partition[i] << endl;
    }

    //modifiedCost = calculateCutCost(adjList, partition);
    //cout << "Modified cut cost: " << modifiedCost << endl;

    //cout << "Modified cut cost: " << modifiedCost << endl;
    //cout<<partition0Count<<" "<<n;
    fin.close();
    fout.close();
    return 0;
}
