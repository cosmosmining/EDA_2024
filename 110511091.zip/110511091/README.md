
# BDD Manipulation Program with CUDD

This program uses the CUDD package to manipulate Binary Decision Diagrams (BDDs). It reads a Sum of Products (SOP) expression and a variable order from an input file, then computes and outputs the size of the smallest BDD representing the expression, based on variable permutations.

## Prerequisites

- CUDD Package: The program is dependent on the CUDD package for BDD manipulations. Ensure that CUDD is installed and properly configured on your system.

## Compilation

The provided Makefile can be used to compile the program. Simply run the following command in the terminal:

```bash
make
```

This command compiles the C++ source code and links it with the CUDD library to generate the executable.

## Execution

To run the program, use the following command:

```bash
./your_executable_name input_file.txt output_file.txt
```

Replace `your_executable_name` with the name of the generated executable, `input_file.txt` with the path to your input file containing the SOP expression and variable order, and `output_file.txt` with the path where you want the output (the size of the smallest BDD) to be written.

### Input File Format

The input file should contain:
- A line with the SOP expression, where capital letters indicate the negation of a variable.
- A line with the variable order, indicating the order of variables in the BDD.
- Additional lines may include permutations of the variable order to explore different BDD sizes.

### CUDD Package

This program uses the CUDD package for creating and manipulating BDDs. Ensure that the CUDD libraries are correctly installed and linked during compilation. The Makefile assumes the CUDD library is accessible in the system's library path.

## Output

The output file will contain a single line indicating the size of the smallest BDD found for the given SOP expression, considering possible permutations of the variable order.
