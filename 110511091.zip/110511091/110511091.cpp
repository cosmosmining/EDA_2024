#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>
#include "cudd.h"

int findIndex(char variable, const char* order) {
    for (int i = 0; i < strlen(order); i++) {
        if (tolower(order[i]) == tolower(variable)) {
            return i;
        }
    }
    return -1;
}

DdNode* createProductBDD(DdManager* manager, const char* term, DdNode** vars, const char* variableOrder) {
    DdNode* product = Cudd_ReadOne(manager);
    Cudd_Ref(product);

    for (int i = 0; term[i] != '\0'; i++) {
        int index = findIndex(term[i], variableOrder);
        DdNode* var = vars[index];

        if (isupper(term[i])) {
            var = Cudd_Not(var);
        }

        DdNode* temp = Cudd_bddAnd(manager, product, var);
        Cudd_Ref(temp);
        Cudd_RecursiveDeref(manager, product);
        product = temp;
    }

    return product;
}

int main(int argc, char* argv[]) {
    if (argc != 3) {
        printf("Usage: %s <input_file> <output_file>\n", argv[0]);
        return 1;
    }

    FILE *fp = fopen(argv[1], "r");
    FILE *fout = fopen(argv[2], "w");
    if (!fp) {
        perror("Failed to open input file");
        return 1;
    }
    if (!fout) {
        perror("Failed to open output file");
        fclose(fp);
        return 1;
    }

    char line[1024];
    if (fgets(line, sizeof(line), fp) == NULL) {
        fprintf(stderr, "Failed to read SOP expression\n");
        fclose(fp);
        fclose(fout);
        return 1;
    }
    line[strcspn(line, ".\n")] = '\0';
    char* sopExpression = strdup(line);

    if (fgets(line, sizeof(line), fp) == NULL) {
        fprintf(stderr, "Failed to read variable order\n");
        fclose(fp);
        fclose(fout);
        free(sopExpression);
        return 1;
    }
    line[strcspn(line, ".\n")] = '\0';
    char* variableOrder = strdup(line);

    DdManager* manager = Cudd_Init(0, 0, CUDD_UNIQUE_SLOTS, CUDD_CACHE_SLOTS, 0);
    DdNode* vars[26]; // Support for 26 variables (a-z)

    for (int i = 0; i < strlen(variableOrder); i++) {
        int index = findIndex(variableOrder[i], variableOrder);
        vars[index] = Cudd_bddIthVar(manager, index);
    }

    DdNode* sop = Cudd_ReadLogicZero(manager);
    Cudd_Ref(sop);

    char* token = strtok(sopExpression, "+");
    while (token != NULL) {
        DdNode* product = createProductBDD(manager, token, vars, variableOrder);
        DdNode* temp = Cudd_bddOr(manager, sop, product);
        Cudd_Ref(temp);
        Cudd_RecursiveDeref(manager, sop);
        Cudd_RecursiveDeref(manager, product);
        sop = temp;

        token = strtok(NULL, "+");
    }

    int smallestNodeSize = Cudd_DagSize(sop);

    while (fgets(line, sizeof(line), fp)) {
        line[strcspn(line, ".\n")] = '\0'; // Remove the trailing period

        int perm[Cudd_ReadSize(manager)];
        // Initialize the permutation array with an identity permutation
        for (int i = 0; i < Cudd_ReadSize(manager); i++) {
            perm[i] = i;
        }

        // Read and apply the permutation from the file
        for (int i = 0; i < strlen(line); i++) {
            if (line[i] == '\0') break; // Stop if we reach the end of the line
            int varIndex = findIndex(line[i], variableOrder);
            if (varIndex != -1 && varIndex < Cudd_ReadSize(manager)) {
                perm[varIndex] = i;
            }
        }
        DdNode* permutedSop = Cudd_bddPermute(manager, sop, perm);
        Cudd_Ref(permutedSop); // Make sure the result is persisted

        int currentSize = Cudd_DagSize(permutedSop);
        if (currentSize < smallestNodeSize) {
            smallestNodeSize = currentSize;
        }

        // Dereference the permuted BDD to avoid memory leaks
        Cudd_RecursiveDeref(manager, permutedSop);
    }

    // Output the smallest BDD size found
    fprintf(fout,"%d\n",smallestNodeSize+1);

    // Cleanup
    Cudd_RecursiveDeref(manager, sop);
    Cudd_Quit(manager);
    fclose(fp);
    fclose(fout);
    free(sopExpression);
    free(variableOrder);

    return 0;
}
